from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Inventory, Order, Supplier, CustomerOrder

class SignupForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

class InventoryForm(forms.ModelForm):
    class Meta:
        model = Inventory
        fields = ['name', 'quantity', 'price']

class OrderForm(forms.ModelForm):
    class Meta:
        model = Order
        fields = ['item', 'status']

class SupplierForm(forms.ModelForm):
    class Meta:
        model = Supplier
        fields = ['name', 'contact']

class CustomerSignupForm(UserCreationForm):
    email = forms.EmailField()
    address = forms.CharField(widget=forms.Textarea)
    phone = forms.CharField()

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2', 'address', 'phone']

class CustomerOrderForm(forms.ModelForm):
    class Meta:
        model = CustomerOrder
        fields = ['quantity']
