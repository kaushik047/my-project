from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.models import User
from .models import Inventory, Order, Supplier, Customer, CustomerOrder
from .forms import InventoryForm, OrderForm, SupplierForm, SignupForm, CustomerSignupForm, CustomerOrderForm
from django.contrib.auth.decorators import login_required

@login_required
def dashboard(request):
    inventory_items = Inventory.objects.count()
    pending_orders = Order.objects.filter(status="Pending").count()
    total_suppliers = Supplier.objects.count()
    return render(request, 'home/dashboard.html', {
        'inventory_items': inventory_items,
        'pending_orders': pending_orders,
        'total_suppliers': total_suppliers
    })

@login_required
def inventory_page(request):
    items = Inventory.objects.all()
    if request.method == 'POST':
        form = InventoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('inventory')
    else:
        form = InventoryForm()
    return render(request, 'home/inventory.html', {'items': items, 'form': form})

@login_required
def delete_inventory(request, id):
    item = get_object_or_404(Inventory, id=id)
    item.delete()
    return redirect('inventory')

@login_required
def orders_page(request):
    orders = Order.objects.all()
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('orders')
    else:
        form = OrderForm()
    return render(request, 'home/orders.html', {'orders': orders, 'form': form})

@login_required
def process_order(request, id):
    order = get_object_or_404(Order, id=id)
    order.status = "Processed"
    order.save()
    return redirect('orders')

@login_required
def suppliers_page(request):
    suppliers = Supplier.objects.all()
    if request.method == 'POST':
        form = SupplierForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('suppliers')
    else:
        form = SupplierForm()
    return render(request, 'home/suppliers.html', {'suppliers': suppliers, 'form': form})

@login_required
def delete_supplier(request, id):
    supplier = get_object_or_404(Supplier, id=id)
    supplier.delete()
    return redirect('suppliers')

def signup_view(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = SignupForm()
    return render(request, 'home/signup.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('dashboard')
    else:
        form = AuthenticationForm()
    return render(request, 'home/login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('login')

def customer_signup(request):
    if request.method == 'POST':
        form = CustomerSignupForm(request.POST)
        if form.is_valid():
            user = form.save()
            Customer.objects.create(user=user, address=form.cleaned_data['address'], phone=form.cleaned_data['phone'])
            return redirect('customer_login')
    else:
        form = CustomerSignupForm()
    return render(request, 'home/customer_signup.html', {'form': form})

def customer_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('medicine_list')
    else:
        form = AuthenticationForm()
    return render(request, 'home/customer_login.html', {'form': form})

@login_required
def medicine_list(request):
    medicines = Inventory.objects.filter(quantity__gt=0)
    return render(request, 'home/medicine_list.html', {'medicines': medicines})

@login_required
def place_order(request, medicine_id):
    medicine = get_object_or_404(Inventory, id=medicine_id)
    customer = get_object_or_404(Customer, user=request.user)
    if request.method == 'POST':
        form = CustomerOrderForm(request.POST)
        if form.is_valid():
            quantity = form.cleaned_data['quantity']
            if quantity <= medicine.quantity:
                total_price = quantity * medicine.price
                medicine.quantity -= quantity
                medicine.save()
                CustomerOrder.objects.create(
                    customer=customer,
                    medicine=medicine,
                    quantity=quantity,
                    total_price=total_price,
                    payment_status="Paid",
                    delivery_status="Delivered"
                )
                return render(request, 'home/order_success.html', {'medicine': medicine})
    else:
        form = CustomerOrderForm()
    return render(request, 'home/place_order.html', {'form': form, 'medicine': medicine})

def role_selection(request):
    return render(request, 'home/role_selection.html')


# Machine Learning Integration
from sklearn.linear_model import LinearRegression
import numpy as np

@login_required
def forecast_view(request):
    days = np.array([1, 2, 3, 5, 7, 10, 14, 20, 25, 30]).reshape(-1, 1)
    sales = np.array([2, 5, 7, 10, 13, 18, 25, 30, 32, 35])

    model = LinearRegression()
    model.fit(days, sales)

    future_days = np.array(range(31, 38)).reshape(-1, 1)
    predictions = model.predict(future_days).astype(int)

    forecast = zip(range(31, 38), predictions)
    return render(request, 'home/forecast.html', {'forecast': forecast})
