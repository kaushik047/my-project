from django.urls import path
from .views import (
    dashboard,
    inventory_page,
    delete_inventory,
    orders_page,
    process_order,
    suppliers_page,
    delete_supplier,
    signup_view,
    login_view,
    logout_view,
    customer_signup,
    customer_login,
    medicine_list,
    place_order,
    role_selection,
    forecast_view
)

urlpatterns = [
    path('login/', login_view, name='login'),
    path('dashboard/', dashboard, name='dashboard'),
    path('inventory/', inventory_page, name='inventory'),
    path('inventory/delete/<int:id>/', delete_inventory, name='delete_inventory'),
    path('orders/', orders_page, name='orders'),
    path('orders/process/<int:id>/', process_order, name='process_order'),
    path('suppliers/', suppliers_page, name='suppliers'),
    path('suppliers/delete/<int:id>/', delete_supplier, name='delete_supplier'),
    path('signup/', signup_view, name='signup'),
    path('logout/', logout_view, name='logout'),

    path('customer/signup/', customer_signup, name='customer_signup'),
    path('customer/login/', customer_login, name='customer_login'),
    path('customer/medicines/', medicine_list, name='medicine_list'),
    path('customer/order/<int:medicine_id>/', place_order, name='place_order'),
    path('', role_selection, name='role_selection'),
    path('forecast/', forecast_view, name='forecast'),

]
