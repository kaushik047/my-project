from django.contrib import admin
from .models import Inventory, Order, Supplier

admin.site.register(Inventory)
admin.site.register(Order)
admin.site.register(Supplier)
